#
# Copyright (c) 2022. All rights reserved.
#
#

export UBYON_LOG_DIR="/home/ubyon/logs"
export CORE_PATTERN="/home/ubyon/cores/%e.core.%p.%s"
export PATH="/home/ubyon/bin:$PATH"
export TLS_CA_CERT="/home/ubyon/certs/edge_ca.crt"
export TLS_CLIENT_CERT="/home/ubyon/certs/tls.crt"
export TLS_CLIENT_KEY="/home/ubyon/certs/tls.key"

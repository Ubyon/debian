#
# Copyright (c) 2022. All rights reserved.
#
#

export UBYON_LOG_DIR="/home/ubyon/logs"
export CORE_PATTERN="/home/ubyon/cores/%e.core.%p.%s"
export PATH="/home/ubyon/bin:$PATH"
